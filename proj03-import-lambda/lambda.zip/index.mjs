console.log('Loading function');

export const handler = async (event, context) => {
    return "Another welcome message from Terraform. Greg East."
};
